export class SpendDetails {

    id: String;
    email: String;
    spendType: String;
    category: String;
    vendor: String;
    invoiceAmount: String;
    spendDate: Date;
}
