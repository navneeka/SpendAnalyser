export class User {

    id: String;
    username: String;
    password: String;

}